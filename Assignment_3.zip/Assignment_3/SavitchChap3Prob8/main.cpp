/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 1:11 AM
 * Savitch Chapter 3 Problem 8
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int c, f;
    c=100;
    cout<<"The displayed table shows the values of celsius and fahrenheit till they both have the same value"<<endl;
    cout<<"Celsius\t\tFahrenheit"<<endl;
    do{
        c--;
        f=((9*c)/5)+32;
        cout<<"  "<<c<<"\t\t"<<f<<endl;
    }while(c!=f);
    cout<<"Below 100, in temperature, both fahrenheit and celsius are equal to "<<c<<endl;
    //exit stage right
    return 0;
}

