/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 11:29 PM
 * Savitch Chapter 3 problem 4
 */

//System libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    double interest, b, ai, l;
    int m;
    char again;
    do{
        //input loan
        cout<<"Input the amount of the loan"<<endl;
        cin>>l;
        //interest rate input
        cout<<"Input interest rate"<<endl;
        cin>>interest;
        //monthly payment
        cout<<" Monthly payment = "<<(l/20)<<endl;
        ai=0;
        b=l;
        m=0;
        while(b>0){
            ai +=((interest*b)/(100*12));
            m++;
            b-=((l/20)-((interest*b)/(100*12)));
            if(b<0)
                b=0;
             cout<<" Remaining balance "<<b<<endl;
        }
        //annualized interest
        cout<<"Annualized interest is "<<((ai*100*12)/(l*m));
    cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
     cin>>again;
        }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

