/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 12:53 AM
 * Savitch Chapter 3 Problem 7
 */

//System libraries
#include <iostream>
using namespace std;

//Global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
   double w, bf, r;
   //enter weight
   cout<<"In pounds input the weight of the object"<<endl;
   cin>>w;
   //enter radius
   cout<<"In feet input the radius of the object"<<endl;
   cin>>r;
   //buoyant force
   bf=62.4*((4*3.14*r*r*r)/3);
   if(bf>=w)
       cout<<"The object will float";
   else
       cout<<"The object will sink";
//exit stage right
    return 0;
}

