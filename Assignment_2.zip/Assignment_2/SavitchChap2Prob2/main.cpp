/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 5:39 PM
 * Savitch Chapter 2 Problem 2
 * calculate salary
 */

//system libraries
#include <iostream>
using namespace std;

//Global constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    double salary_prev, amount_due, salary_annual, salary_monthly;
    const double salary_increase=.076;
    char again;
    do {
        //input previous salary
        cout<<"Enter previous annual salary"<<endl;
        cin>>salary_prev;
        //calculate amount due
        amount_due=((salary_prev * salary_increase)/2);
        //output amount of pay due
        cout<<"Previous salary pay due is "<<amount_due<<endl;
        //calculate annual salary
        salary_annual=(salary_prev * (1 + salary_increase));
        //output annual salary
        cout<<"The employee's new annual salary is "<<salary_annual<<endl;
        //calculate monthly salary
        salary_monthly=((salary_prev * (1 + salary_increase))/12);
        //output monthly salary
        cout<<"The employee's new monthly salary is "<<salary_monthly<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'y');//repeat calculation
        //exit stage right
    return 0;
}

