/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 12:04 AM
 * Savitch Chapter 1 Problem 5
 * To output the sum of two integers
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    int first_number, second_number, total_number;
    
    cout << "Hello" <<endl;
    
    cout << "Press return after entering a number.\n";
    cout << "Enter the first number to be added:\n";
    
    cin >> first_number;
    
    cout << "Enter the second number to be added:\n";
    cin >> second_number;
    total_number = first_number + second_number;
    cout << "The total sum is  ";
    cout << total_number <<endl;
    cout << "This is the end of the program.\n";
    
    return 0;
}

