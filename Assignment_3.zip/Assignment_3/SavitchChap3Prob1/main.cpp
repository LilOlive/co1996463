/*
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 9:36 PM
 * Savitch Chapter 3 Problem 1
 */

//System libraries
#include <iostream>
using namespace std;

//Global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    char firstpick, secondpick, pick, again;
    do{
        for (int i=0; i<2; i++){
            do{
                //input pick
                cout<<"Enter your pick P, R or S"<<endl;
                cin>>pick;
            }while(pick != 'p' && pick !='P' && pick !='r' && pick !='R' && pick !='s' && pick !='S');
                if(i==0){
                    firstpick= pick;
                }
                else if(i==1){
                    secondpick= pick;
                }
        }
        if(firstpick==secondpick){
            cout<<"The result is a draw and end of game"<<endl;
        }
        else {
            if(firstpick=='p' || firstpick=='P'){
                if(secondpick=='s' || secondpick=='S'){
                  cout<<"Scissor cuts paper, second player wins round"<<endl;  
                }
                else {
                    cout<<"Paper covers rock, first player wins round"<<endl;
                }
            }
            if(firstpick=='s' || firstpick=='S'){
                if(secondpick=='p' || secondpick=='P'){
                    cout<<"Scissor cuts paper, first player wins round"<<endl;
                }
                else {
                    cout<<"Rock breaks scissor, second player wins round"<<endl;
                }
            }   
            if (pick=='r' || firstpick=='r'){
                if(secondpick=='s' || secondpick=='S'){
                    cout<<"Rock breaks scissor, first player wins round"<<endl;
                }
                else{
                    cout<<"Paper covers rock, second player wins round"<<endl;
                }
            }
        }
        //repeat
       cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right      
    return 0;
}

