/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 3:29 PM
 * Savitch Chapter 1 Problem 9
 * finding the distance
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    int time, distance, acceleration;
    cout << "Press return after entering a number.\n";
    cout << "Enter the time:\n";
    
    cin >> time;
    
    acceleration = 32; //feet per second
    distance = (acceleration * (time * time))/2;
    
    cout << "The object has gone\n";
    cout << distance << " (ft per second)" <<endl;
    
    return 0;
}

