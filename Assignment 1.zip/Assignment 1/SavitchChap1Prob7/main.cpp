/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 10:29 AM
 * Savitch Chapter 1 Problem 7
 * Printout CS! in large block letters
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
        cout << "    **************************************************\n";
        cout << "               C C C               S S S S       !!   \n";
        cout << "            C         C          S         S     !!   \n";
        cout << "           C                    S                !!   \n";
        cout << "          C                      S               !!   \n";
        cout << "         C                         S S S S       !!   \n";
        cout << "         C                                 S     !!   \n";
        cout << "          C                                 S    !!   \n";
        cout << "            C         C          S         S          \n";
        cout << "               C C C               S S S S       00   \n";
        cout << "     *************************************************\n";
        cout << "          Computer Science is Cool Stuff!!!\n";

    return 0;
}

