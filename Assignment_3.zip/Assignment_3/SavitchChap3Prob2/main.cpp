/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 10:22 PM
 * Savitch Chapter 3 Problem 2
 */

//System libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    char again;
    double amount, interest, payment, balance;
    do{
        //input balance
        cout<<"Enter the balance that is due"<<endl;
        cin>>balance;
        if(balance>1000)
        //calculate the rate of interest
            interest=((balance-1000)*.01+(1000)*.015);
        else
        //calculate interest
         interest=balance*.015;
        //calculate amount
         amount=balance+interest;
         //calculate payment
         payment=amount<=10?
             amount:((amount*.1)>10? (amount*.1):10);
         //output
         cout<<"Balance interest is "<<interest<<endl;
         cout<<"The amount due is "<<amount<<endl;
         cout<<"Payment is "<<payment<<endl;
         cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

