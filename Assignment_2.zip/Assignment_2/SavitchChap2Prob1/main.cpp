/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 4:51 PM
 * Savitch Chapter 2 Problem 1
 * finding the amount of sweetener that can be consumed
 */

//System Libraries
#include <iostream>
using namespace std;

//Global constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare Variables
    double kill_mouse, mouse_weight, dieter_weight, amount_sweetener;
    char again;
    do {
        //input sweetener weight
        cout<<"Enter the weight of the sweetener that can kill a mouse"<<endl;
        cin>>kill_mouse;
        //input mouse weight
        cout<<"Enter the mouses weight"<<endl;
        cin>>mouse_weight;
        //input the weight that the diet will stop
        cout<<"Enter the weight that the you will stop the diet"<<endl;
        cin>>dieter_weight;
        //amount calculation
        amount_sweetener=((kill_mouse * dieter_weight)/(mouse_weight * .001));
        //output
        cout<<"Without dieting the amount of soda that can be consumed is "<<amount_sweetener<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then enter "<<endl;
        cin>>again;
    }while(again=='y' || again=='y');//calculate repeat
    //exit stage right
    return 0;
}

