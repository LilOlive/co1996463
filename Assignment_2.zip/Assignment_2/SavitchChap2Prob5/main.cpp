/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 7:19 PM
 * Savitch Chapter 2 Problem 5
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int capacity, people, invited;
    char again;
    do{
        //input maximum capacity
        cout<<"Enter rooms maximum capacity "<<endl;
        cin>>capacity;
        //input the number of people attending
        cout<<"Enter the number of people attending "<<endl;
        cin>>people;
        // if there is less than capacity
        if(people<=capacity){
            cout<<"The meeting can be legally started"<<endl;
            if(capacity - people){
            cout<<capacity - people;
            cout<<" more people can attend"<<endl;
        }//end of second if
        }//end of first if
        else {
            cout<<"Meeting can not be legally started "<<endl;
            cout<<people - capacity;
            cout<<" people must be excluded in order to start the meeting legally"<<endl;
        } // end of else
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

