/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 9:10 PM
 * Savitch Chapter 2 Problem 10
 */

//System libraries
#include <iostream>
using namespace std;

//Global constants

//Function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int totneg=0, totpos=0;
    double pos=0, neg=0,tot=0, num;
    //input
    cout<<"Enter negative and positive numbers and press enter after each one"<<endl;
    for(int i=0; i<10; i++){
        cin>>num;
        tot += num;
        if(num>0)
        {
            pos += num;
            totpos++;
        }
        else
        {
            neg += num;
            totneg++;
        }
    }
    //output positive
    cout<<"All positive numbers sum is "<<pos<<endl;
    //average of positive numbers
    cout<<"The average of the positive numbers is "<<pos/totpos<<endl;
    //output negative numbers
    cout<<"All negative numbers sum is "<<neg<<endl;
    //average of negative numbers
    cout<<"The average of the negative numbers is "<<pos/totneg<<endl;
    //output total
    cout<<"Total sum is "<<tot<<endl;
    //average of all numbers
    cout<<"The total average is "<<tot/10<<endl;
    //exit stage right
    return 0;
}



