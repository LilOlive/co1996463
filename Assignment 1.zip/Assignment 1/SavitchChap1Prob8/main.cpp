/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 12:53 PM
 * Savitch Chapter 1 Problem 8
 * Output coins worth
 */

#include <iostream>
using namespace std;
 
int main(int argc, char** argv) {
    int number_of_quarters, number_of_dimes, number_of_nickels, total_change;
    
    cout << "Press return after entering a number.\n";
    cout << "Enter the number of quarters:\n";
    cin >> number_of_quarters;
          
    cout << "Enter the number of dimes:\n";
    cin >> number_of_dimes;
    cout << "Enter the number of nickels:\n";
    cin >> number_of_nickels;
    total_change = number_of_quarters * 25 + number_of_dimes * 10 + number_of_nickels * 05;
    cout << "If you have ";
    cout << number_of_quarters;
    cout << " quarters,\n";
    cout << number_of_dimes;
    cout << " dimes,\n";
    cout << "and ";
    cout << number_of_nickels;
    cout << " nickels, then\n";
    cout << "you have ";
    cout << total_change;
    cout << " cents total in change\n";
    
    return 0;
}

