/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 8:37 PM
 * Savitch Chapter 2 Problem 8
 */

//System Libraries
#include <iostream>
using namespace std;

//Global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    double amount_loan, pay_monthly, interest_rate, interest_pay, e=0,l, i, m, p, r;
    char again;
    //input value
    cout<<"Enter loan amount"<<endl;
    cin>>amount_loan;
    cout<<"Enter interest per year"<<endl;
    cin>>interest_pay;
    cout<<"Enter monthly pay"<<endl;
    cin>>pay_monthly;
    l = amount_loan;
    cout<<endl;
    cout<<endl;
    for (i=1; l>0; i++){
        interest_rate=interest_pay/100/12;
        r = interest_rate * l;
        m = pay_monthly - r;
        cout<<"Month "<<i<<endl;
        cout<<"Interest "<<r<<endl;
        cout<<"Remaining "<<m<<endl;
        l = l - m;
        cout<<"Remaining balance is "<<l<<endl;
        p = e + r;
        e = p;
    }
    i = i - 1;
    if(l<-.1)
        l = l*-1;
    else if (l>.1)
        l=l*1;
    //output
    cout<<"The month total is "<<i<<endl;
    cout<<"The interest total is "<<p<<endl;
    cout<<"Your credit is "<<l<<endl;
    cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
    cin>>again;
    while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

