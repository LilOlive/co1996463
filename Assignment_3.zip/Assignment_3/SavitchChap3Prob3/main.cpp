/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 10:38 PM
 * Savitch Chapter 3 Problem 3
 */

//System libraries
#include <iostream>
#include <cmath>
using namespace std;

//Global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int a, b, c;
    double d;
    char again;
    do{
        cout<<"Quadratic equation is ax^2+bx+c=0"<<endl;
        cout<<"Calculate the variable x"<<endl;
        //value a
        cout<<"Input the value for a"<<endl;
        cin>>a;
        //value b
        cout<<"Input the value for b"<<endl;
        cin>>b;
        //value c
        cout<<"Input the value for c"<<endl;
        cin>>c;
        //Calculate e
        d=(b*b-4*a*c);
        if(d==0){
            cout<<"The equations root value is "<<-b/a<<endl;
        }
        else if(d>0){
            cout<<"The root of equation is "<<(((-1*b)+sqrt(d))/(2*a));
            cout<<" and "<<(((-1*b)-sqrt(d))/(2*a))<<endl;
        }
        else{
            cout<<"Roots(complex)"<<endl;
            cout<<"The root of the equation is "<<(-1*b)/(2*a)<<" +i"<<sqrt(-1*d)<<endl;
            cout<<(-1*b)/(2*a)<<" -i"<<sqrt(-1*d)<<endl;
        }
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

