/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 1:35 AM
 * Savitch Chapter 3 Problem 9
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int tn, tn1, tn2, t=0;
    bool c=true;
    //enter a value
    cout<<"Input a temperature value"<<endl;
    cin>>tn;
    //number between 0 and 999
    if(tn>=0 && tn>=999){
        cout<<"Input a number between 0 and 999"<<endl;
        cin>>tn;
    }
    //assign numbers
    tn1=tn;
    tn2=tn;
    while(c){
        while (tn1!=0) {
            //single digit
            t=tn1%10;
            //temp contains 4 or 1 or 7
            if(t==1 || t==4 || t==7)
                break;
            else
                tn1=tn1/10;
        }
        if(tn1==0)
            c= false;
        else
           tn1=--tn2;
    }
    cout<<tn2;
    c= true;
    while (c){
        while(tn1!=0){
            //single digit
            t=tn1%10;
            //check for 1 or 4 or 7
            if(t==1 || t==4 || t==7)
                break;
            else
                tn1=tn1/10;
        }
        if(tn1==0)
            c= false;
        else
            tn1=++tn2;
    }
    cout<<"  "<<tn2;
    //exit stage right
    return 0;
}

