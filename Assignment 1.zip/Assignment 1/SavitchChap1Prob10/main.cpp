/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 3:48 PM
 * Savitch Chapter 1 Problem 10
 * Compose a large block letter C with any inputed Character
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    char shape_c;
    
    cout << "Press return after entering a character.\n";
    cout << "Enter any character from the alphabet: \n";
    
    cin >> shape_c;
    
    cout << "\n\n";
    cout << "  " <<  shape_c << "  " << shape_c << "  " << shape_c << "\n";
    cout << " " << shape_c << "        " << shape_c << "\n";
    cout << shape_c << "\n";
    cout << shape_c << "\n";
    cout << shape_c << "\n";
    cout << shape_c << "\n";
    cout << shape_c << "\n";
    cout << " " << shape_c << "        " << shape_c << "\n";
    cout << "  " <<  shape_c << "  " << shape_c << "  " << shape_c << "\n";
   
    return 0;
}

