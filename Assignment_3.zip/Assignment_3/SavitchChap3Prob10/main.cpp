/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 2:14 AM
 * Savitch Chapter 3 Problem 10
 */

//System libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    int u, tp=23;
    while(tp>0){
        do{
            cout<<"Player 1"<<endl;
              cin>>u;
        }while(u>4);
        tp=tp-u;
        if(tp==0){
            cout<<"Player 1 loses game"<<endl;
            break;
        }
        cout<<"Computer"<<endl;
        if (tp>4){
            tp=(tp-u*4);
        }
        else if(tp>=2 && tp<=4){
            if (tp==2)
                tp=tp-1;
            if(tp==4)
                tp=tp-3;
        }
        cout<<"The computer chooses "<<tp<<endl;
        if(tp==0){
            cout<<"The computer loses game"<<endl;
        }
    }
    //exit stage right
    return 0;
}

