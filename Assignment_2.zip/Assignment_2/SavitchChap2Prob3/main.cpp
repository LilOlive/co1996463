/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 5:39 PM
 * Savitch Chapter 2 Problem 3
 * calculate salary
 */

//system libraries
#include <iostream>
using namespace std;

//Global constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int months_number;
    double salary_prev, amount_due, salary_annual, monthly_increase, prevSalary_monthly, salary_monthly;
    const double salary_increase=.076;
    char again;
    do {
        //input previous salary
        cout<<"Enter previous annual salary"<<endl;
        cin>>salary_prev;
        //enter number of months
        cout<<"Enter a number of months"<<endl;
        cin>>months_number;
       //calculate previous monthly salary
        prevSalary_monthly=salary_prev/12;
        //calculate monthly increase
        monthly_increase=prevSalary_monthly * salary_increase;
        //calculate pay due
        amount_due=monthly_increase * months_number;
        //calculate the new monthly salary
        salary_monthly=monthly_increase + prevSalary_monthly;
        //calculate the new annual salary
        salary_annual=salary_monthly * 12;
        //output
        cout<<"The pay due is "<<amount_due<<endl;
        cout<<"The employee's new annual salary is "<<salary_annual<<endl;
        cout<<"The employee's new monthly salary is "<<salary_monthly<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
        //exit stage right
    return 0;
}

