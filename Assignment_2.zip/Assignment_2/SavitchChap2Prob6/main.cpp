/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 7:43 PM
 * Savitch Chapter 2 Problem 6
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    int hours_worked, number_dependents;
    double gross_pay;
    char again;
    do {
        //input hours
        cout<<"Enter the number of hours worked per week"<<endl;
        cin>>hours_worked;
        //input dependents
        cout<<"Enter the number of dependents you have"<<endl;
        cin>>number_dependents;
        //calculate
        gross_pay= hours_worked>40?((40 * 16.78) + (hours_worked - 40) * (16.78 * 1.5)) : (hours_worked * 16.78);
        //output
        cout<<"Gross pay is "<<gross_pay<<endl;
        cout<<"The amount that is taken for Social Security tax is "<<(.06 * gross_pay)<<endl;
        cout<<"The amount that is taken for federal income tax is "<<(.14 * gross_pay)<<endl;
        cout<<"The amount that is taken for state income tax is "<<(.05 * gross_pay)<<endl;
        cout<<"The amount that is taken for union dues is $10"<<endl;
        if(number_dependents>=3) {
            cout<<"The amount taken for insurance cost is $35"<<endl;
            gross_pay-=35;
        }
        cout<<"The take home pay for the employee is "<<(gross_pay * (1 - .06 - .05 - .14) - 10)<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

