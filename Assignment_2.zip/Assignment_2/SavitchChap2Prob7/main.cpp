/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 8:05 PM
 * Savitch Chapter 2 Problem 7
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //declare variables
    int number_years;
    double cost_item, rate_inflation;
    char again;
    do{
        //input present cost
        cout<<"Enter the present cost of the item"<<endl;
        cin>>cost_item;
        //input inflation
        cout<<"Enter the inflation rate"<<endl;
        cin>>rate_inflation;
        //input years
        cout<<"Enter the number of years"<<endl;
        cin>>number_years;
        //calculations
        rate_inflation/=100;
        for (int i=0; i<number_years; i++){
            cost_item *= (1 + rate_inflation);
        }
       cout<<"The cost of the item after "<<number_years<<" will be "<<cost_item<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

