/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 12:37 AM
 * Savitch Chapter 3 Problem 6
 */

//System libraries
#include <iostream>
#include <cmath>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    char again;
    int n, i, p, b=1;
    double pi;
    do{
        pi=0;
        //n value
        cout<<"Input the value for n"<<endl;
        cin>>n;
        for(i=1, p=2; i<n; i++, p++){
            pi=pi+pow((-1),p)*4/b;
            b=b+2;
        }
        cout<<"pi value is "<<pi<<endl;
        cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
     cin>>again;
        }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

