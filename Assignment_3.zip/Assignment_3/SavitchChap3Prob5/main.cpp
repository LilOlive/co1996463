/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 20, 2014, 12:07 AM
 * Savitch Chapter 3 Problem 5
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //declare variables
    int p, d, pp=10, t=p;
    char again;
    do{
        //enter beginning population
        cout<<"Input beginning population"<<endl;
        cin>>p;
        //enter amount of days
        cout<<"After how many days do you want to know the number of the population"<<endl;
        cin>>d;
        d=d/5;
        //verification
        if(d<=2){
            cout<<" The population remains as "<<p;
        }
        else{
            for(int i=2; i<d; i++){
                p+=pp;
                pp=t;
            }
            cout<<"The population will be "<<p<<endl;
        }
         cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
     cin>>again;
        }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

