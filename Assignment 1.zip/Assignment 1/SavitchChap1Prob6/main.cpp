/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 11, 2014, 12:24 AM
 * Savitch Chapter 1 Problem 6
 * Create and record error
 * ERROR: 
        main.cpp:9:20: error: missing terminating > character
        #include < iostream
        main.cpp:9:20: fatal error:  iostream: No such file or directory
        compilation terminated.
 *      main.cpp:20:22: error: invalid operands of types ‘const char [6]’ and ‘<unresolved overloaded function type>’ to binary ‘operator<<’
     cout < "Hello" <<endl;
 */

#include <iostream>
using namespace std;

int main() {
    int number_of_pods, peas_per_pod, total_peas;
    
    cout << "Hello" <<endl;
    
    cout << "Press return after entering a number.\n";
    cout << "Enter the number of pods:\n";
    
    cin >> number_of_pods;
    
    cout << "Enter the number of peas in a pod:\n";
    cin >> peas_per_pod;
    total_peas = number_of_pods * peas_per_pod;
    cout << "If you have ";
    cout << number_of_pods;
    cout << " pea pods\n";
    cout << "and ";
    cout << peas_per_pod;
    cout << " peas in each pod, then\n";
    cout << "you have ";
    cout << total_peas;
    cout << " peas in all the pods.\n";
    cout << "Good-bye\n";
    
    return 0;
}

