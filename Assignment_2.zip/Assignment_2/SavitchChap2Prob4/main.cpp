/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 19, 2014, 6:54 PM
 * Savitch Chapter 2 Problem 4
 */

//system libraries
#include <iostream>
using namespace std;

//Global constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //declare variables
    double time, amount, face_value, interest, interest_loan;
    char again;
    do{
        //input amount wish to receive
        cout<<"Enter the amount you would like to receive "<<endl;
        cin>>amount;
        //input the amount of time that is needed
       cout<<"Enter the time that is need for the amount "<<endl;
       cin>>time;
       //input rate of interest
       cout<<"Enter the rate of interest for the loan in percent "<<endl;
       cin>>interest;
       //calculations
       interest_loan= interest/100;//interest calculation to convert to decimal
       face_value= amount/ (1 - time * interest_loan);//face value
       //output
       cout<<"You need a loan amount of "<<face_value<<endl;
       cout<<"The monthly installments would be "<<(face_value/ (time * 12))<<endl;
       cout<<"To repeat this calculation with different variables press 'y' then press enter "<<endl;
        cin>>again;
    }while(again== 'y' || again== 'Y');//repeat calculation
    //exit stage right
    return 0;
}

